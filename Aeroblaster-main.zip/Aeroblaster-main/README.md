# Aeroblaster

![image](https://user-images.githubusercontent.com/65861136/121507694-8c1bdb00-c9ed-11eb-809f-6df7ca9f5d25.png)

Aeroblaster is a platformer shooter in which the world loops vertically. Your objective is to shoot the cores while avoiding the projectiles. Loop around to get a more tactical approach!

This is a series of Games created by DaFluffyPotato to help python programmers in their routine
